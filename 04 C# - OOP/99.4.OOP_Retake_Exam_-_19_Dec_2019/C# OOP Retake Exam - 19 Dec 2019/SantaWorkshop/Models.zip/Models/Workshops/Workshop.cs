﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SantaWorkshop.Models.Dwarfs.Contracts;
using SantaWorkshop.Models.Presents.Contracts;
using SantaWorkshop.Models.Workshops.Contracts;

namespace SantaWorkshop.Models.Workshops
{
    public class Workshop : IWorkshop
    {
        public Workshop()
        {
            
        }

        public void Craft(IPresent present, IDwarf dwarf)
        {
            while (true)
            {
                if (dwarf.Energy == 0)
                {
                    break;
                }

                if (dwarf.Instruments.FirstOrDefault() == null)
                {
                    break;
                }

                var instrument = dwarf.Instruments.FirstOrDefault();

                if (instrument.IsBroken())
                {
                    dwarf.Instruments.Remove(instrument);
                    continue;
                }

                present.GetCrafted();
                instrument.Use();

                if (instrument.IsBroken())
                {
                    dwarf.Instruments.Remove(instrument);
                    continue;
                }

                if (dwarf.Energy ==0)
                {
                    break;
                }

                if (present.IsDone())
                {
                    break;
                }
            }
        }
    }
}
