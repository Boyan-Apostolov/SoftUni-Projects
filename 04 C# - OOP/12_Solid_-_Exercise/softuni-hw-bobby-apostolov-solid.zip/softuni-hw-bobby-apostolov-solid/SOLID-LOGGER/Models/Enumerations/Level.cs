﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLID_LOGGER.Models.Enumerations
{
    public enum Level
    {
        INFO,
        WARNING,
        ERROR,
        CRITICAL,
        FATAL
    }
}
