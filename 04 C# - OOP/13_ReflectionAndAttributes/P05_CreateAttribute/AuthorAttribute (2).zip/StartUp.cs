﻿using System;

namespace P05_CreateAttribute
{
    [Author("Gosho")]
    public class StartUp
    {
        [Author("Ventsi")]
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
