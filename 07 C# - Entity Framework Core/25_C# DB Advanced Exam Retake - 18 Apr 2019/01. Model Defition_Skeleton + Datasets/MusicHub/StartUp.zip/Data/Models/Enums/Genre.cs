﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusicHub.Data.Models.Enums
{
    public enum Genre
    {
        Blues,
        Rap, 
        PopMusic, 
        Rock, 
        Jazz
    }
}
