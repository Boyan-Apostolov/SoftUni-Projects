﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    internal static class Configuration
    {
        internal static string connectionString = "Server=.;Database=FootballBettingSystem;Integrated Security=true;";
    }
}
