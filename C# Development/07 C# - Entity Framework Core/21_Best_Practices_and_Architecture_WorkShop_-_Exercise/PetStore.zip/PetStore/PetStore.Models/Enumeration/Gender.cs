﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PetStore.Models.Enumeration
{
    public enum Gender
    {
        Male = 1,
        Female = 2
    }
}
