﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PetStore.Models.Enumeration
{
    public enum ProductType
    {
        Food = 1,
        Toy = 2,
        Decoration = 3
    }
}
