﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_Vehicles.Models.Contracts
{
    public interface IDriveable
    {
        string Drive(double km);
    }
}
