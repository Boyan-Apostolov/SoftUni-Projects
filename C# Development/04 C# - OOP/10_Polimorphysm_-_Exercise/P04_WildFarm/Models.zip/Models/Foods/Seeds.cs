﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04_WildFarm.Models.Foods
{
    public class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {
        }
    }
}
