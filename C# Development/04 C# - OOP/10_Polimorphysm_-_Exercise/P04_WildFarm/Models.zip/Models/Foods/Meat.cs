﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04_WildFarm.Models.Foods
{
    public class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
