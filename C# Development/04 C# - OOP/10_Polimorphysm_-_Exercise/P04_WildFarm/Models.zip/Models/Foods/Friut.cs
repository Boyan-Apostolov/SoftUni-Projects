﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04_WildFarm.Models.Foods
{
    public class Friut : Food
    {
        public Friut(int quantity) : base(quantity)
        {
        }
    }
}
