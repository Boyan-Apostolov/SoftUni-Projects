﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_Telephony
{
    public interface IBrowseble
    {
        string Browse(string url);
    }
}
