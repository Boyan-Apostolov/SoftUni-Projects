﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03_ShoppingSpree.Common
{
    public static class GlobalConstants
    {
        public static  string InvalidNameExceptionMessage ="Name cannot be empty";
        public static  string InvalidCostExceptionMessage ="Money cannot be negative";
        public static string IncuffiecntMoneyExpetionMessage = "{0} can't afford {1}";
    }
}
